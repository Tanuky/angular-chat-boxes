import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './app-footer.component.html'
})

/*
 * AppFooterComponent UI component to display the footer of the application
 */
export class AppFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
